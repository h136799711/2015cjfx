﻿SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE `cjfx_wxuser`;
insert into `cjfx_wxuser`(`id`,`nickname`,`avatar`,`referrer`,`openid`,`score`,`money`,`costmoney`,`createtime`,`updatetime`,`status`,`notes`,`wxaccount_id`,`sex`,`province`,`city`,`country`,`subscribed`,`subscribe_time`,`groupid`) values
('1','奢侈的自由','http://wx.qlogo.cn/mmopen/etibbrEkCpy8u9WaODzOfEuVmFZ3JfzGgXeyQaWrrXTdsMTiaNN3n2gXkZkPesBIoM3Mv981Wnc9PexAZZibEeEoqHDiawwicUdEf/0','2','oqMIVt3Ouq-2Vm0kZOZmZ2rTDlP8','0',0.00,0.00,'1426746626','1426746626','1','','1','1','浙江','绍兴','中国','0','1426747786','0'),
('2','H先生','http://wx.qlogo.cn/mmopen/PiajxSqBRaEKMjyibRzibDNlia1E6rqTW2Fp69xMdKBc7NZ7s41EK6lhh0BOyk0LBxPdZ0nHoCE3U3jqZibhRrhr1Eg/0','0','oqMIVt5aLt6bsS8Nnk_DHx5_l0UI','0',0.00,0.00,'1426745784','1426745784','1','','1','1','浙江','杭州','中国','1','1426745784','0'),
('4','随心','http://wx.qlogo.cn/mmopen/ajNVdqHZLLDZAicUFaYZjJpibPwbKzgfahl8eTyBMWeOBzK1vibRqYHl3c3FLv27Pcv7ZW64bfNsdH341hTEGIZlA/0','1','oqMIVt1k5kvF_q0GlrWO9GR9x2hs','0',0.00,0.00,'1426758622','1426758622','1','','1','1','浙江','温州','中国','1','1426758638','0'),
('5','就是个搞网络的','http://wx.qlogo.cn/mmopen/etibbrEkCpyicd6NEZicNdibFHIsbHr058o3c6e4R2skRRicuCYf0H38aU5wIwasz0xJzRowLCLaxL45k61iakbVskhB03pV9b9KkN/0','4','oqMIVtwcgGVc46ErSP3Z_DOT-BGM','0',0.00,0.00,'1426760047','1426760047','1','','1','1','都灵','','意大利','1','1426760047','0');
TRUNCATE TABLE `cjfx_wxuser_family`;
insert into `cjfx_wxuser_family`(`id`,`parent_1`,`parent_2`,`parent_3`,`parent_4`,`parent_5`,`createtime`,`wxaccount_id`,`openid`) values
('1','2','0','0','0','0','1426670777','1','oqMIVt3Ouq-2Vm0kZOZmZ2rTDlP8'),
('2','0','0','0','0','0','1426745784','1','oqMIVt5aLt6bsS8Nnk_DHx5_l0UI'),
('3','1','2','0','0','0','1426758622','1','oqMIVt1k5kvF_q0GlrWO9GR9x2hs'),
('4','4','1','2','0','0','1426759296','1','oqMIVtwcgGVc46ErSP3Z_DOT-BGM');
TRUNCATE TABLE `cjfx_commission`;
insert into `cjfx_commission`(`id`,`openid`,`commission_1`,`commission_2`,`commission_3`,`commission_4`,`updatetime`,`commission_6`,`wxaccount_id`) values
('1','oqMIVt3Ouq-2Vm0kZOZmZ2rTDlP8',0.00,0.00,0.00,0.00,'1426670777',0.00,'1'),
('2','oqMIVt5aLt6bsS8Nnk_DHx5_l0UI',0.00,0.00,0.00,0.00,'1426745784',0.00,'1'),
('3','oqMIVt1k5kvF_q0GlrWO9GR9x2hs',0.00,0.00,0.00,0.00,'1426758622',0.00,'1'),
('4','oqMIVtwcgGVc46ErSP3Z_DOT-BGM',0.00,0.00,0.00,0.00,'1426759296',0.00,'1');
SET FOREIGN_KEY_CHECKS = 1;

